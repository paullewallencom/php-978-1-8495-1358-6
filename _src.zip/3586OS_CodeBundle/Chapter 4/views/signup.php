Signup

<form action="<?php echo $this->make_route('/signup') ?>" method="post">
	<label for="name">Name</label>
	<input id="name" name="name" type="text"> <br />
	<input type="Submit" value="Submit">
</form>