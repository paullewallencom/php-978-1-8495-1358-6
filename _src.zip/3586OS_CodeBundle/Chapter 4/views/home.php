Home Page <br /><br />
<?php echo $message; ?>