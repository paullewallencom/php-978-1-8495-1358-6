<!DOCTYPE html><html lang="en">
  <head>
    <link href="<?php echo $this->make_route('/css/master.css') ?>" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h1>Verge</h1>
    <?php include($this->content); ?>
  </body>
</html>