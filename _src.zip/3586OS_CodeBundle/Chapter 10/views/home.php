<div class="hero-unit">
  <h1>Welcome to Verge!</h1>
  <p>Verge is a simple social network that will make you popular.</p>
  <p><a href="<?php echo $this->make_route('/signup') ?>"  class="btn btn-primary btn-large">Signup Now</a></p>
</div>